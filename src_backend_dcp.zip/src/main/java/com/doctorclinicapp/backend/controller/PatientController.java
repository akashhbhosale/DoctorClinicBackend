package com.doctorclinicapp.backend.controller;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.doctorclinicapp.backend.dto.CreatePatientRequest;
import com.doctorclinicapp.backend.dto.PatientResponse;
import com.doctorclinicapp.backend.dto.UpdatePatientRequest;
import com.doctorclinicapp.backend.model.Patient;
import com.doctorclinicapp.backend.service.PatientService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/patients")
public class PatientController {

	private final PatientService patientService;

	// Constructor Injection
	public PatientController(PatientService patientService) {
		this.patientService = patientService;
	}

	// -------------------------------
	// CREATE / UPDATE PATIENT
	// -------------------------------
	@PostMapping("/save")
	public ResponseEntity<Patient> savePatient(
	        @RequestBody @jakarta.validation.Valid CreatePatientRequest req) {

	    Patient patient = Patient.builder()
	            .abhaId(req.getAbhaId())
	            .fullName(req.getFullName())
	            .gender(req.getGender())
	            .dateOfBirth(req.getDateOfBirth())
	            .email(req.getEmail())
	            .phoneNo(req.getPhoneNo())
	            .age(req.getAge())
	            .occupation(req.getOccupation())
	            .bloodGroup(req.getBloodGroup())
	            .address(req.getAddress())
	            .build();

	    Patient savedPatient = patientService.savePatient(patient);
	    return ResponseEntity.status(HttpStatus.CREATED).body(savedPatient);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<PatientResponse> updatePatient(
	        @PathVariable Long id,
	        @RequestBody @Valid UpdatePatientRequest req) {

	    Patient updated = patientService.updatePatient(id, req);

	    return ResponseEntity.ok(PatientResponse.fromEntity(updated));
	}

	// -------------------------------
	// GET PATIENT BY ID
	// -------------------------------
	@GetMapping("/{id}")
	public ResponseEntity<Patient> getPatientById(@PathVariable Long id) {
		Optional<Patient> patient = patientService.getPatientById(id);
		return patient.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// -------------------------------
	// DELETE PATIENT BY ID (soft delete — see PatientService for why)
	// -------------------------------
	@DeleteMapping("/delete/{id}")
	@org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Void> deletePatient(@PathVariable Long id) {
		patientService.deletePatient(id);
		return ResponseEntity.noContent().build();
	}

	// -------------------------------
	// GET ARCHIVED (SOFT-DELETED) PATIENTS
	// -------------------------------
	@GetMapping("/archived")
	@org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<Page<PatientResponse>> getArchivedPatients(
			@PageableDefault(size = 10, sort = "fullName") Pageable pageable) {

		Page<Patient> patientPage = patientService.getArchivedPatients(pageable);

		Page<PatientResponse> responsePage =
				patientPage.map(PatientResponse::fromEntity);

		return ResponseEntity.ok(responsePage);
	}

	// -------------------------------
	// RESTORE AN ARCHIVED PATIENT
	// -------------------------------
	@PutMapping("/restore/{id}")
	@org.springframework.security.access.prepost.PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<PatientResponse> restorePatient(@PathVariable Long id) {
		Patient restored = patientService.restorePatient(id);
		return ResponseEntity.ok(PatientResponse.fromEntity(restored));
	}

	// -------------------------------
	// SEARCH BY ABHA ID
	// -------------------------------
	@GetMapping("/abha/{abhaId}")
	public ResponseEntity<Patient> getByAbhaId(@PathVariable String abhaId) {
		Optional<Patient> patient = patientService.getPatientByAbhaId(abhaId);
		return patient.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// -------------------------------
	// SEARCH BY PHONE NUMBER
	// -------------------------------
	@GetMapping("/phone/{phoneNo}")
	public ResponseEntity<Patient> getByPhoneNo(@PathVariable String phoneNo) {
		Optional<Patient> patient = patientService.getPatientByPhoneNo(phoneNo);
		return patient.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// -------------------------------
	// SEARCH BY FULL NAME (PAGINATED)
	// -------------------------------
	@GetMapping("/search")
	public ResponseEntity<Page<PatientResponse>> searchPatients(
	        @RequestParam String query,
	        Pageable pageable) {

	    Page<Patient> page = patientService.searchPatients(query, pageable);

	    Page<PatientResponse> responsePage =
	            page.map(PatientResponse::fromEntity);

	    return ResponseEntity.ok(responsePage);
	}

	// -------------------------------
	// GET ALL PATIENTS (PAGINATED)
	// -------------------------------
	@GetMapping
	public ResponseEntity<Page<PatientResponse>> getAllPatients(
	        @PageableDefault(size = 10, sort = "fullName") Pageable pageable) {

	    Page<Patient> patientPage = patientService.getAllPatients(pageable);

	    Page<PatientResponse> responsePage =
	            patientPage.map(PatientResponse::fromEntity);

	    return ResponseEntity.ok(responsePage);
	}


}


